# VLine Aim Reach Add-on (Minecraft 26.1.2 / Fabric)

This is a separate companion mod for private worlds/servers that explicitly allow extra reach. It uses the server's native interaction validation and is not an anti-cheat bypass.

## GitHub build

This workflow works in either of two layouts:

1. All project files are at the repository root; or
2. Only this project ZIP is at the repository root. The workflow recognizes this Reach Add-on ZIP, extracts the source files, then builds. It ignores unrelated ZIPs.

After pushing the files or ZIP, open **Actions** and run **Build VLine Aim Reach Add-on**. On success, download the `vlineaim-reach-minecraft-26.1.2` artifact. It contains the add-on JAR and a combined ZIP with the supplied VLine Aim JAR.

## Intended behavior

The source aims for a modest server-authorized interaction range bonus. Extra range in multiplayer requires the server to run the add-on too. The build has not been executed in this environment, so check the Actions log for API/compiler errors before installing.

package com.vlineaim.reach;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.Holder;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

/**
 * Server-authoritative reach extension for worlds/servers that choose to install it.
 * It does not bypass server validation or anti-cheat checks.
 */
public final class VLineAimReachAddon implements ModInitializer {
    // Conservative bonuses: vanilla survival is normally 3 blocks for entities
    // and 4.5 blocks for blocks, so this results in 4 and 5 blocks respectively.
    private static final double ENTITY_REACH_BONUS = 1.0;
    private static final double BLOCK_REACH_BONUS = 0.5;

    private static final Identifier ENTITY_REACH_ID =
            Identifier.fromNamespaceAndPath("vlineaim_reach", "entity_reach_bonus");
    private static final Identifier BLOCK_REACH_ID =
            Identifier.fromNamespaceAndPath("vlineaim_reach", "block_reach_bonus");

    private static final AttributeModifier ENTITY_REACH_MODIFIER = new AttributeModifier(
            ENTITY_REACH_ID,
            ENTITY_REACH_BONUS,
            AttributeModifier.Operation.ADD_VALUE
    );
    private static final AttributeModifier BLOCK_REACH_MODIFIER = new AttributeModifier(
            BLOCK_REACH_ID,
            BLOCK_REACH_BONUS,
            AttributeModifier.Operation.ADD_VALUE
    );

    @Override
    public void onInitialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                ensureModifier(player, Attributes.ENTITY_INTERACTION_RANGE, ENTITY_REACH_MODIFIER);
                ensureModifier(player, Attributes.BLOCK_INTERACTION_RANGE, BLOCK_REACH_MODIFIER);
            }
        });
    }

    private static void ensureModifier(
            ServerPlayer player,
            Holder<Attribute> attribute,
            AttributeModifier modifier
    ) {
        AttributeInstance instance = player.getAttribute(attribute);
        if (instance != null && !instance.hasModifier(modifier.id())) {
            instance.addTransientModifier(modifier);
        }
    }
}
